=======
License
=======

``TemGym Basic`` is licensed under the :choosealicense:`gpl-3.0`

.. license-info:: GPL-3.0

.. license::
    :file: ../LICENSE.md