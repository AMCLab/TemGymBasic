=============
Documentation
=============
.. automodule:: functions
    :members:
    :special-members:
.. automodule:: components
    :members:
    :special-members:
.. automodule:: geometry
    :members:
    :special-members:
.. automodule:: gui
    :members:
    :special-members:
.. automodule:: model
    :members:
    :special-members:
.. automodule:: run
    :members:
    :special-members:
