============
Bibliography
============

Papers
^^^^^^

Papers mentioned accross the documentation are referenced here. 

- Toshiaki Tanigaki, Yoshikatsu Inada, Shinji Aizawa, Takahiro Suzuki, Hyun Soon Park, 
  Tsuyoshi Matsuda, Akira Taniyama, Daisuke Shindo, and Akira Tonomura , "Split-illumination electron holography", 
  Appl. Phys. Lett. 101, 043101 (2012) https://doi.org/10.1063/1.4737152

