# Tem Gym Basic

An interactive first order ray tracing software for electron microscopes written in python.
See [documentation](https://temgymbasic.readthedocs.io/en/latest/) on readthedocs for more info. 